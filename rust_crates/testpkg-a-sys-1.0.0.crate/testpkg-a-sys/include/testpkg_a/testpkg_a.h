#ifndef TESTPKG_A_H
#define TESTPKG_A_H

#include <testpkg_b/testpkg_b.h>

namespace testpkg_a {
    const char* get_name();
}

#endif
