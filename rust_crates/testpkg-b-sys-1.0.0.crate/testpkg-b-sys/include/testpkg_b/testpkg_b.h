#ifndef TESTPKG_B_H
#define TESTPKG_B_H

#include <testpkg_c/testpkg_c.h>

namespace testpkg_b {
    const char* get_name();
}

#endif
