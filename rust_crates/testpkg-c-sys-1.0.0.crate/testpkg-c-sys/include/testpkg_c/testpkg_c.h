#ifndef TESTPKG_C_H
#define TESTPKG_C_H

namespace testpkg_c {
    const char* get_name();
}

#endif
